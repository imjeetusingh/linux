#!/bin/bash

# Path to the text file containing the list of usernames
usernames_file="usernames.txt"

# Check if the file exists
if [ ! -f "$usernames_file" ]; then
  echo "Usernames file not found."
  exit 1
fi

# Read each username from the file and delete the corresponding user
while read -r username; do
  if id "$username" >/dev/null 2>&1; then
    echo "Deleting user: $username"
    userdel -r "$username"
  else
    echo "User $username not found."
  fi
done < "$usernames_file"

echo "User deletion process completed."

