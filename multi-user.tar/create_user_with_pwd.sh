#!/bin/bash

# Path to the text file containing the list of usernames
usernames_file="usernames.txt"

# Group to add the users to
group_name="ltib12"

# Check if the file exists
if [ ! -f "$usernames_file" ]; then
  echo "Usernames file not found."
  exit 1
fi

# Read each username from the file, create the user, set the password, and add to the group
while read -r username; do
  if id "$username" >/dev/null 2>&1; then
    echo "User $username already exists."
  else
    echo "Creating user: $username"
    useradd "$username" -m -p "$(openssl passwd -1 'pass@word1')"  # Set password as 'pass@word1'
    usermod -a -G "$group_name" "$username"  # Add user to the group
    echo "User $username created and added to group $group_name."
  fi
done < "$usernames_file"

echo "User creation process completed."

