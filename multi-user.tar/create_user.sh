#!/bin/bash

# Check if the script is run as root
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root."
   exit 1
fi

# Define the path to the text file containing the usernames
usernames_file="usernames.txt"

# Check if the usernames file exists
if [ ! -f "$usernames_file" ]; then
    echo "Usernames file not found."
    exit 1
fi

# Create the group
groupadd ltib12
echo "Group 'ltib12' created."

# Read each line from the usernames file and create users
while IFS= read -r username; do
    # Check if the user already exists
    if id "$username" >/dev/null 2>&1; then
        echo "User '$username' already exists. Skipping..."
    else
        # Create the user and add it to the group
        useradd -m -G ltib12 "$username"
        echo "User '$username' created and added to group 'ltib12'."
    fi
done < "$usernames_file"

echo "User creation process complete."

